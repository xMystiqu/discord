const Utils = require("../../modules/utils");
const config = Utils.variables.config;
const lang = Utils.variables.lang;
const createTicket = require('../../modules/methods/createTicket');

module.exports = {
    name: 'new',
    run: async (bot, message, args) => {
        createTicket(bot, args, message.member, message.channel);
    },
    description: "Create a ticket",
    usage: config.Tickets.RequireReason ? 'new <reason>' : 'new [reason]',
    aliases: [
        'ticket'
    ]
}
// 223901   8501   2458037    63250   1627746875   469245647f87d26fdb818c4728c23669218a3b67   2458037