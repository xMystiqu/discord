const Utils = require("../modules/utils");

module.exports = async (bot, invite) => {
    Utils.updateInviteCache(bot)
}
// 223901   8501   2458037    63250   1627746875   469245647f87d26fdb818c4728c23669218a3b67   2458037